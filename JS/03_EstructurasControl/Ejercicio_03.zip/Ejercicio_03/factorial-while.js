// factorial-while

let factorial = 1
let i = 1

while(i <=10){
    factorial = factorial * i    
    i++;    
}
console.log(factorial)
