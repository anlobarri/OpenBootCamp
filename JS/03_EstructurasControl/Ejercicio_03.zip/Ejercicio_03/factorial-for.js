// factorial-for.js

let number = 10
let factorial = 1

for(let i = 1; i <= number; i++){
    factorial = factorial * i   
}
console.log(factorial)