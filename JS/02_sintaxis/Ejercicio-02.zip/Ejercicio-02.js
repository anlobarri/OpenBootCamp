// Ejercicio tema 02

const fechaNacimiento = new Date("20 March 1986");
const libroFavorito = {
    titulo: "Ready Player One",
    autor: "Ernest Cline",
    fecha: new Date("16 august 2011"),
    url: "https://es.wikipedia.org/wiki/Ready_Player_One",
};

const lista = ["Angel", 36, true, fechaNacimiento, libroFavorito]

console.log(lista)