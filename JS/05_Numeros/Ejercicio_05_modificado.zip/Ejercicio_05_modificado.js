let altura_cm = 172
let altura_m = 1.72
let peso_kg = 65.5

let altura_m_redondeo = altura_m.toFixed()
let peso_redondeo = Math.floor(peso_kg)

let sonIguales = Number.MAX_VALUE + 1 === Number.MAX_VALUE